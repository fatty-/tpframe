<?php
/**
 * @link http://www.tpframe.com/
 * @copyright Copyright (c) 2017 TPFrame Software LLC
 * @author 510974211@qq.com
 */

namespace tpfcore\helpers;

use tpfcore\base\ErrorException;
use tpfcore\base\InvalidConfigException;
use tpfcore\base\InvalidParamException;

class BaseFileHelper
{
    
}
