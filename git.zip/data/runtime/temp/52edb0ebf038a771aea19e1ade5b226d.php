<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:32:"./theme/backend/index\index.html";i:1517221508;}*/ ?>
<!DOCTYPE html>
<html lang="zh_CN" style="overflow: hidden;">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<meta charset="utf-8">
<title>TPFrame 后台管理中心</title>
<meta name="description" content="This is page-header (.page-header &gt; h1)">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="__THEMES__/css/theme.min.css" rel="stylesheet">
<link href="__THEMES__/css/simplebootadmin.css" rel="stylesheet">
<link href="__THEMES__/css/font-awesome.min.css"  rel="stylesheet" type="text/css">
<!--[if IE 7]> <link rel="stylesheet" href="__THEMES__/css/font-awesome-ie7.min.css"> <![endif]-->
<link rel="stylesheet" href="__THEMES__/css/simplebootadminindex.min.css?">
<link href="__THEMES__/css/default.css" rel="stylesheet" />
<!--[if lte IE 8]> <link rel="stylesheet" href="__THEMES__/css/simplebootadminindex-ie.css?" /> <![endif]-->
<style>
.navbar .nav_shortcuts .btn {
  margin-top: 5px;
}
.macro-component-tabitem {
  width: 101px;
}
/*-----------------导航hack--------------------*/
.display{display: none;}
.nav-list>li.open {
  position: relative;
}
.nav-list>li.open .back {
  display: none;
}
.nav-list>li.open .normal {
  display: inline-block !important;
}
.nav-list>li.open a {
  padding-left: 7px;
}
.nav-list>li .submenu>li>a {
  background: #fff;
}
.nav-list>li .submenu>li a>[class*="fa-"]:first-child {
  left: 20px;
}
.nav-list>li ul.submenu ul.submenu>li a>[class*="fa-"]:first-child {
  left: 30px;
}
.logo{width: 30px; height: auto;}
.main-nav{list-style: none; margin-left: 30px;}
.main-nav li{line-height: 36px; margin-left: 10px; margin-top: 6px; padding: 0 20px; color: #FFF; cursor: pointer;}
.main-nav li.actived{background-color: #FFF; color: #424242;}
/*----------------导航hack--------------------*/
</style>
<script type="text/javascript">//全局变量
var GV = {
      HOST:"www.tpframe.com",
      ROOT: "/",
      WEB_ROOT: "/",
      JS_ROOT: "public/js/"
};
if(window.top.length>0){
  window.top.location.href='<?php echo url("Index/index"); ?>';
}
</script>
</head>
<body style="min-width:900px;" screen_capture_injected="true">
<div id="loading"><i class="loadingicon"></i><span>正在加载...</span></div>
<div id="right_tools_wrapper"> <span id="right_tools_clearcache" title="清除缓存" onclick="javascript:openapp('<?php echo url('setting/clear'); ?>','right_tool_clearcache','清除缓存',true);"><i class="fa fa-trash-o right_tool_icon"></i></span> <span id="refresh_wrapper" title="REFRESH_CURRENT_PAGE" ><i class="fa fa-refresh right_tool_icon"></i></span> </div>
<div class="navbar">
  <div class="navbar-inner">
    <div class="container-fluid"> <a href="<?php echo url('Index/index'); ?>" class="brand"><img class="logo" src="__THEMES__/images/logo.png"/> <small> TPFrame后台管理中心 </small> </a>
      <div class="pull-left nav_shortcuts" > <a class="btn btn-small btn-warning" href="/" title="网站首页" target="_blank"> <i class="fa fa-home"></i> </a></div>
      <ul class="pull-left main-nav">
        <?php if(is_array($listMianNav) || $listMianNav instanceof \think\Collection || $listMianNav instanceof \think\Paginator): $i = 0; $__LIST__ = $listMianNav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <li class="pull-left display" key="<?php echo $vo['id']; ?>"><?php echo $vo['name']; ?></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </ul>
      <ul class="nav simplewind-nav pull-right">
        <li class="light-blue"> <a data-toggle="dropdown" href="#" class="dropdown-toggle"> <img class="nav-user-photo" width="30" height="30" src="__THEMES__/images/logo.png" alt="demo"> <span class="user-info"> 欢迎, <?php echo \think\Session::get('backend_author_sign.username'); ?> </span> <i class="fa fa-caret-down"></i> </a>
          <ul class="user-menu pull-right dropdown-menu dropdown-yellow dropdown-caret dropdown-closer">
            <li><a href="javascript:openapp('<?php echo url('Setting/site'); ?>','index_site','网站信息');"><i class="fa fa-cog"></i> 网站信息</a></li>
            <li><a href="javascript:openapp('<?php echo url('Member/userinfo'); ?>','index_userinfo','修改信息');"><i class="fa fa-user"></i> 修改信息</a></li>
            <li><a href="javascript:openapp('<?php echo url('Member/uppwd'); ?>','index_password','修改密码');"><i class="fa fa-lock"></i> 修改密码</a></li>
            <li><a href="<?php echo url('User/loginout'); ?>"><i class="fa fa-sign-out"></i> 退出</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</div>
<div class="main-container container-fluid">
  <div class="sidebar" id="sidebar"> <!-- <div class="sidebar-shortcuts" id="sidebar-shortcuts"> </div> -->
    <div id="nav_wraper">
      <?php if(is_array($listTree) || $listTree instanceof \think\Collection || $listTree instanceof \think\Paginator): $i = 0; $__LIST__ = $listTree;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
      <ul class="nav display nav-list nav-item<?php echo $vo['parentid']; ?>">
        <li> 
        <a href="#" class="dropdown-toggle"> <i class="fa fa-<?php echo $vo['icon']; ?> normal"></i> <span class="menu-text normal"> <?php echo $vo['name']; ?> </span> 
        <b class="arrow fa fa-angle-right normal"></b> 
        </a>
        <?php if(!(empty($vo['son']) || (($vo['son'] instanceof \think\Collection || $vo['son'] instanceof \think\Paginator ) && $vo['son']->isEmpty()))): ?>
          <ul class="submenu">
            <?php if(is_array($vo['son']) || $vo['son'] instanceof \think\Collection || $vo['son'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['son'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$child): $mod = ($i % 2 );++$i;?>
            <li><a href="javascript:openapp('<?php echo url($child['controller'].'/'.$child['action'],$child['urlext']); ?>','<?php echo $child['id']; ?>Admin','<?php echo $child['name']; ?>',true);" class="dropdown-toggle"><i class="fa fa-caret-right"></i> <span class="menu-text"> <?php echo $child['name']; ?> </span> <b class="arrow fa fa-angle-right"></b></a>
              <?php if(!(empty($child['son']) || (($child['son'] instanceof \think\Collection || $child['son'] instanceof \think\Paginator ) && $child['son']->isEmpty()))): ?>
              <ul class="submenu">
              <?php if(is_array($child['son']) || $child['son'] instanceof \think\Collection || $child['son'] instanceof \think\Paginator): $i = 0; $__LIST__ = $child['son'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$son): $mod = ($i % 2 );++$i;?>
                <li> <a href="javascript:openapp('<?php echo url($son['controller'].'/'.$son['action'],$son['urlext']); ?>','<?php echo $son['id']; ?>Admin','<?php echo $son['name']; ?>',true);"> &nbsp;<i class="fa fa-angle-double-right"></i> <span class="menu-text"> <?php echo $son['name']; ?> </span> </a> </li>
              <?php endforeach; endif; else: echo "" ;endif; ?>
              </ul>
              <?php endif; ?>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
          </ul>
        <?php endif; ?>
        </li>
      </ul>
      <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
  </div>
  <div class="main-content">
    <div class="breadcrumbs" id="breadcrumbs"> <a id="task-pre" class="task-changebt">←</a>
      <div id="task-content">
        <ul class="macro-component-tab" id="task-content-inner">
          <li class="macro-component-tabitem noclose" app-id="0" app-url="/admin/main/index.html" app-name="首页"> <span class="macro-tabs-item-text">首页</span> </li>
        </ul>
        <div style="clear:both;"></div>
      </div>
      <a id="task-next" class="task-changebt">→</a> </div>
    <div class="page-content" id="content">
      <iframe src="<?php echo url('Index/main'); ?>" style="width:100%;height: 100%;" frameborder="0" id="appiframe-0" class="appiframe"></iframe>
    </div>
  </div>
</div>
<script src="__THEMES__/js/jquery.js"></script> 
<script src="__THEMES__/js/wind.js"></script> 
<script src="__THEMES__/js/bootstrap.min.js"></script> 
<script type="text/javascript"> var ismenumin = $("#sidebar").hasClass("menu-min");
  $(".nav-list").on("click",function(event) {
    var closest_a = $(event.target).closest("a");
    if (!closest_a || closest_a.length == 0) {
      return
    }
    if (!closest_a.hasClass("dropdown-toggle")) {
      if (ismenumin && "click" == "tap" && closest_a.get(0).parentNode.parentNode == this) {
        var closest_a_menu_text = closest_a.find(".menu-text").get(0);
        if (event.target != closest_a_menu_text && !$.contains(closest_a_menu_text, event.target)) {
          return false
        }
      }
      return
    }
    var closest_a_next = closest_a.next().get(0);
    if (!$(closest_a_next).is(":visible")) {
      var closest_ul = $(closest_a_next.parentNode).closest("ul");
      if (ismenumin && closest_ul.hasClass("nav-list")) {
        return
      }
      closest_ul.find("> .open > .submenu").each(function() {
            if (this != closest_a_next && !$(this.parentNode).hasClass("active")) {
              $(this).slideUp(150).parent().removeClass("open")
            }
      });
    }
    if (ismenumin && $(closest_a_next.parentNode.parentNode).hasClass("nav-list")) {
      return false;
    }
    $(closest_a_next).slideToggle(150).parent().toggleClass("open");
    return false;
  });
  </script> 
  <script src="__THEMES__/js/common.js"></script> 
  <script src="__THEMES__/js/index.js"></script>
  <script type="text/javascript">
    $(function(){
      // 初始化
      removeEmpayNav();
      initNav();
      $(".main-nav li").click(function(){
        var key=$(this).attr("key");
        if(!$(this).hasClass("actived")){
          $(this).siblings("li").removeClass("actived");
          $(this).addClass("actived");
          $(".nav-list").hide();
          $(".nav-item"+key).show();
        }
      });
      function initNav(){
        var firstNav=$(".main-nav li:first");
        firstNav.addClass("actived");
        var key=firstNav.attr("key");
        $(".nav-item"+key).show();
      }
      function removeEmpayNav(){
        $(".main-nav li").each(function(k,v){
          var key=$(this).attr("key");
          if($(".nav-item"+key).length==0){
            $(this).remove();
          }
          $(this).show();
        });
      }
    });
  </script>
</body>
</html>