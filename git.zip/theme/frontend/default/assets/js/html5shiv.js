<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>404错误，未找到页面</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description"/>
	<meta content="" name="keywords"/>
</head>
<body style="background: #faf7f2">

<div align="center">
	
	<a href="http://ux.xunhuweb.com"><img style="max-width:100%;"  src="http://ux.xunhuweb.com/wp-content/themes/xh-design/404.jpg"/></a>
</div>
</body>
</html>