<?php 
return array (
  'DEFAULT_THEME' => 'default',
  'HTML_CACHE_ON' => false,
);