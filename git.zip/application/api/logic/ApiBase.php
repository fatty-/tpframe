<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\api\logic;

use app\common\logic\LogicBase;
use \tpfcore\Core;
use think\Validate;

class ApiBase extends LogicBase
{
	
}