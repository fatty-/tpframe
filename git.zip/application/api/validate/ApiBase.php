<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\api\validate;

use app\common\validate\ValidateBase;

/**
 * api基础验证器
 */
class ApiBase extends ValidateBase 
{
	
}
