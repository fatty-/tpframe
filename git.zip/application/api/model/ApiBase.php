<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\api\model;

use app\common\model\ModelBase;

/**
 * Api基础模型
 */
class ApiBase extends ModelBase
{
    
}
