<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\api\controller;
use \tpfcore\Core;

class Index extends ApiBase
{
	public function index(){
		echo "欢迎使用api接口";
	}
}