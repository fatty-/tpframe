<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\api\controller;
use \tpfcore\Core;
use app\common\controller\ControllerBase;

class ApiBase extends ControllerBase
{
	
}