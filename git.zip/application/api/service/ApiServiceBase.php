<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\api\service;

use app\common\service\ServiceBase;

/**
 * Api基础服务
 */
class ApiServiceBase extends ServiceBase
{

}
