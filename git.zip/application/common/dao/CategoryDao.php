<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------
namespace app\common\dao;
/*	
*	数据处理接口
*/
interface CategoryDao extends InterfaceBase
{
	public function getCategory();
}
?>