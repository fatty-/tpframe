<?php
namespace app\common\logic;

use app\common\model\ModelBase;
/*	
*	逻辑基类
*/
class LogicBase extends ModelBase
{

}
?>