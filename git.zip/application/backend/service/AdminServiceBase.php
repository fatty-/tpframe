<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\backend\service;

use app\common\service\ServiceBase;

/**
 * Admin基础服务
 */
class AdminServiceBase extends ServiceBase
{

}
