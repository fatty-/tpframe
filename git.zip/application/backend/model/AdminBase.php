<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\backend\model;

use app\common\model\ModelBase;

/**
 * Admin基础模型
 */
class AdminBase extends ModelBase
{
    
}
