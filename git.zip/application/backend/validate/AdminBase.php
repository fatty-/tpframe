<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\backend\validate;

use app\common\validate\ValidateBase;

/**
 * Admin基础验证器
 */
class AdminBase extends ValidateBase 
{


}
