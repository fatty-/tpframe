<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\frontend\model;
use think\Model;

class SlideCat extends FrontendBase 
{
}
?>