<?php
// +----------------------------------------------------------------------
// | Author: yaoyihong <510974211@qq.com>
// +----------------------------------------------------------------------

namespace app\frontend\validate;

use app\common\validate\ValidateBase;

/**
 * 基础验证器
 */
class FrontendBase extends ValidateBase 
{


}
